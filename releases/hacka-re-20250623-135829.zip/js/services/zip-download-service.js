/**
 * ZIP Download Service
 * Generates a ZIP file containing all essential hacka.re files for local deployment
 */

// Import JSZip from CDN dynamically
let JSZip;

async function loadJSZip() {
    if (JSZip) return JSZip;
    
    try {
        // Load JSZip library dynamically
        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js';
        script.onload = () => {
            JSZip = window.JSZip;
        };
        document.head.appendChild(script);
        
        // Wait for JSZip to load
        await new Promise((resolve, reject) => {
            const checkJSZip = setInterval(() => {
                if (window.JSZip) {
                    JSZip = window.JSZip;
                    clearInterval(checkJSZip);
                    resolve();
                }
            }, 100);
            
            setTimeout(() => {
                clearInterval(checkJSZip);
                reject(new Error('Failed to load JSZip'));
            }, 10000);
        });
        
        return JSZip;
    } catch (error) {
        console.error('Failed to load JSZip:', error);
        throw error;
    }
}

/**
 * List of essential files to include in the ZIP
 * Excludes test files, documentation, and development-only files
 */
const ESSENTIAL_FILES = [
    // Main entry point
    'index.html',
    
    // Core JavaScript files
    'js/app.js',
    'js/script.js',
    'js/themes.js',
    'js/button-tooltips.js',
    'js/copy-code.js',
    'js/default-functions-tooltip.js',
    'js/function-tooltip.js',
    'js/link-sharing-tooltip.js',
    'js/logo-animation.js',
    'js/logo-tooltip.js',
    'js/logo-typewriter.js',
    'js/mobile-utils.js',
    'js/modal-effects.js',
    'js/settings-tooltip.js',
    
    // Component files
    'js/components/ai-hackare.js',
    'js/components/api-tools-manager.js',
    'js/components/chat-manager.js',
    'js/components/dom-elements.js',
    'js/components/function-calling-manager.js',
    'js/components/mcp-manager.js',
    'js/components/prompts-event-handlers.js',
    'js/components/prompts-manager.js',
    'js/components/prompts-modal-renderer.js',
    'js/components/share-manager.js',
    'js/components/ui-manager.js',
    
    // Configuration files
    'js/config/share-config.js',
    'js/config/share-items-registry.js',
    
    // Service files
    'js/services/api-debugger.js',
    'js/services/api-request-builder.js',
    'js/services/api-response-parser.js',
    'js/services/api-service.js',
    'js/services/api-stream-processor.js',
    'js/services/api-tool-call-handler.js',
    'js/services/api-tools-service.js',
    'js/services/chat-streaming-service.js',
    'js/services/chat-tools-service.js',
    'js/services/chat-ui-service.js',
    'js/services/context-usage-service.js',
    'js/services/core-storage-service.js',
    'js/services/data-service.js',
    'js/services/debug-service.js',
    'js/services/default-functions-service.js',
    'js/services/default-prompts-service.js',
    'js/services/encryption-service.js',
    'js/services/function-tools-config.js',
    'js/services/function-tools-executor.js',
    'js/services/function-tools-logger.js',
    'js/services/function-tools-parser.js',
    'js/services/function-tools-processor.js',
    'js/services/function-tools-registry.js',
    'js/services/function-tools-service.js',
    'js/services/function-tools-storage.js',
    'js/services/link-sharing-service.js',
    'js/services/mcp-client-core.js',
    'js/services/mcp-client-registration.js',
    'js/services/mcp-connection-manager.js',
    'js/services/mcp-metadata-discovery.js',
    'js/services/mcp-oauth-service.js',
    'js/services/mcp-request-manager.js',
    'js/services/mcp-service-connectors.js',
    'js/services/mcp-tool-registry.js',
    'js/services/mcp-transport-service.js',
    'js/services/model-info.js',
    'js/services/namespace-service.js',
    'js/services/prompts-service.js',
    'js/services/share-item-registry.js',
    'js/services/share-service-v2.js',
    'js/services/share-service.js',
    'js/services/storage-service.js',
    'js/services/system-prompt-coordinator.js',
    
    // Utility files
    'js/utils/clipboard-utils.js',
    'js/utils/context-utils.js',
    'js/utils/crypto-utils.js',
    'js/utils/function-markers.js',
    'js/utils/mcp-size-estimator-global.js',
    'js/utils/mcp-size-estimator.js',
    'js/utils/rc4-utils.js',
    'js/utils/tooltip-utils.js',
    'js/utils/ui-utils.js',
    
    // Default functions
    'js/default-functions/api-auth-client.js',
    'js/default-functions/math-utilities.js',
    'js/default-functions/mcp-example.js',
    'js/default-functions/rc4-encryption.js',
    
    // Default prompts
    'js/default-prompts/agent-orchestration.js',
    'js/default-prompts/api-auth-libsodium-core.js',
    'js/default-prompts/api-auth-libsodium-documentation.js',
    'js/default-prompts/api-auth-libsodium-examples.js',
    'js/default-prompts/api-auth-libsodium.js',
    'js/default-prompts/code-section.js',
    'js/default-prompts/function-calling.js',
    'js/default-prompts/function-library.js',
    'js/default-prompts/hacka-re-project.js',
    'js/default-prompts/interpretability-urgency.js',
    'js/default-prompts/mcp-sdk-readme.js',
    'js/default-prompts/openai-proxies-python.js',
    'js/default-prompts/owasp-llm-top10.js',
    
    // Plugin files
    'js/plugins/share-plugin-manager.js',
    
    // CSS files
    'css/checkbox-fix.css',
    'css/copy-code.css',
    'css/default-functions.css',
    'css/default-prompts.css',
    'css/function-calling.css',
    'css/mobile.css',
    'css/styles.css',
    'css/themes.css',
    
    // Library files (local dependencies)
    'lib/dompurify/purify.min.js',
    'lib/font-awesome/all.min.css',
    'lib/highlight.js/github.min.css',
    'lib/highlight.js/highlight.min.js',
    'lib/marked/marked.min.js',
    'lib/qrcode/qrcode.min.js',
    'lib/tweetnacl/nacl-fast.min.js',
    'lib/tweetnacl/nacl-util.min.js',
    
    // Web fonts
    'lib/webfonts/fa-brands-400.ttf',
    'lib/webfonts/fa-brands-400.woff2',
    'lib/webfonts/fa-regular-400.ttf',
    'lib/webfonts/fa-regular-400.woff2',
    'lib/webfonts/fa-solid-900.ttf',
    'lib/webfonts/fa-solid-900.woff2',
    
    // About pages (useful for local users)
    'about/index.html',
    'about/local-llm-toolbox.html',
    'about/architecture.html',
    'about/development.html',
    'about/disclaimer.html',
    'about/research-report.html',
    'about/serverless.html',
    'about/thumbnail.html',
    'about/css/code-popup.css',
    'about/css/styles.css',
    'about/css/themes.css',
    'about/js/code-popup-config.js',
    'about/js/code-popup-core.js',
    'about/js/code-popup-renderer.js',
    'about/js/code-popup.js',
    'about/js/script.js',
    'about/js/themes.js',
    
    // Essential documentation
    'README.md',
    'LICENSE',
    'CLAUDE.md'
];

/**
 * Fetch file content from the server
 */
async function fetchFileContent(filePath) {
    try {
        const response = await fetch(filePath);
        if (!response.ok) {
            throw new Error(`Failed to fetch ${filePath}: ${response.status}`);
        }
        
        // Determine if file is binary based on extension
        const isBinary = /\.(ttf|woff2?|png|jpg|jpeg|gif|ico|zip)$/i.test(filePath);
        
        if (isBinary) {
            return await response.arrayBuffer();
        } else {
            return await response.text();
        }
    } catch (error) {
        console.warn(`Failed to fetch ${filePath}:`, error.message);
        return null; // Skip files that can't be fetched
    }
}

/**
 * Generate and download ZIP file containing all essential hacka.re files
 */
export async function downloadHackaReZip() {
    try {
        // Load JSZip library
        await loadJSZip();
        
        // Create new ZIP instance
        const zip = new JSZip();
        
        // Add a README for the download
        const readmeContent = `# hacka.re - Serverless Chat Interface

This ZIP file contains all the essential files needed to run hacka.re locally.

## Quick Start

1. Extract all files to a directory
2. Open index.html in a web browser
3. Configure your API provider in Settings
4. For local LLMs, see about/local-llm-toolbox.html

## Files Included

- All core JavaScript modules and services
- CSS stylesheets and themes
- Local libraries (no CDN dependencies)
- Web fonts for icons
- Documentation and about pages

## Privacy & Security

- No backend server required
- All data stays in your browser
- Compatible with local LLMs for complete privacy
- Encrypted localStorage for sensitive data

## More Information

Visit https://hacka.re for the latest version and updates.

Generated on: ${new Date().toISOString()}
`;
        
        zip.file('README_DOWNLOAD.txt', readmeContent);
        
        // Add all essential files to ZIP
        let successCount = 0;
        let failCount = 0;
        
        console.log('Starting ZIP generation...');
        
        // Process files in batches to avoid overwhelming the browser
        const batchSize = 10;
        for (let i = 0; i < ESSENTIAL_FILES.length; i += batchSize) {
            const batch = ESSENTIAL_FILES.slice(i, i + batchSize);
            
            await Promise.all(batch.map(async (filePath) => {
                try {
                    const content = await fetchFileContent(filePath);
                    if (content !== null) {
                        zip.file(filePath, content);
                        successCount++;
                        console.log(`✓ Added: ${filePath}`);
                    } else {
                        failCount++;
                        console.warn(`✗ Skipped: ${filePath}`);
                    }
                } catch (error) {
                    failCount++;
                    console.error(`✗ Error adding ${filePath}:`, error);
                }
            }));
            
            // Small delay between batches
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        
        console.log(`ZIP generation complete: ${successCount} files added, ${failCount} files skipped`);
        
        // Generate ZIP file
        console.log('Generating ZIP blob...');
        const zipBlob = await zip.generateAsync({
            type: 'blob',
            compression: 'DEFLATE',
            compressionOptions: {
                level: 6
            }
        });
        
        // Create download link
        const url = URL.createObjectURL(zipBlob);
        const link = document.createElement('a');
        link.href = url;
        
        // Generate filename with timestamp
        const timestamp = new Date().toISOString().slice(0, 19).replace(/[:-]/g, '');
        link.download = `hacka-re-${timestamp}.zip`;
        
        // Trigger download
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // Clean up blob URL
        setTimeout(() => URL.revokeObjectURL(url), 100);
        
        console.log('ZIP download initiated');
        return {
            success: true,
            filesAdded: successCount,
            filesSkipped: failCount,
            filename: link.download
        };
        
    } catch (error) {
        console.error('Failed to generate ZIP:', error);
        throw error;
    }
}

/**
 * Get file size estimate for the ZIP download
 */
export function getEstimatedZipSize() {
    // Rough estimates based on typical file sizes
    const estimates = {
        js: 50, // KB per JS file average
        css: 20, // KB per CSS file average
        lib: 100, // KB per library file average
        fonts: 200, // KB per font file average
        html: 30, // KB per HTML file average
        md: 10 // KB per markdown file average
    };
    
    let totalSize = 0;
    
    ESSENTIAL_FILES.forEach(file => {
        const ext = file.split('.').pop().toLowerCase();
        if (ext === 'js') totalSize += estimates.js;
        else if (ext === 'css') totalSize += estimates.css;
        else if (file.includes('lib/')) totalSize += estimates.lib;
        else if (ext === 'ttf' || ext === 'woff2') totalSize += estimates.fonts;
        else if (ext === 'html') totalSize += estimates.html;
        else if (ext === 'md') totalSize += estimates.md;
        else totalSize += 20; // Default estimate
    });
    
    // Add compression factor (typically 60-70% of original size)
    totalSize = Math.round(totalSize * 0.65);
    
    return {
        estimatedSizeKB: totalSize,
        estimatedSizeMB: Math.round(totalSize / 1024 * 10) / 10,
        fileCount: ESSENTIAL_FILES.length
    };
}
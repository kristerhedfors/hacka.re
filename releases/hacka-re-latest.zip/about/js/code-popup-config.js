/**
 * Code Popup Configuration
 * Module mappings and configuration data for code popup functionality
 */

window.CodePopupConfig = (function() {
    // Map of module names to file paths
    const moduleToFilePath = {
        'EncryptionService': 'js/services/encryption-service.js',
        'CryptoUtils': 'js/utils/crypto-utils.js',
        'NamespaceService': 'js/services/namespace-service.js',
        'CoreStorageService': 'js/services/core-storage-service.js',
        'DataService': 'js/services/data-service.js',
        'StorageService': 'js/services/storage-service.js',
        'ApiService': 'js/services/api-service.js',
        'ChatManager': 'js/components/chat-manager.js',
        'SettingsManager': 'js/components/settings-manager.js',
        'UIManager': 'js/components/ui-manager.js',
        'PromptsManager': 'js/components/prompts-manager.js',
        'ShareManager': 'js/components/share-manager.js',
        'ApiToolsManager': 'js/components/api-tools-manager.js',
        'LinkSharingService': 'js/services/link-sharing-service.js',
        'ShareService': 'js/services/share-service.js',
        'PromptsService': 'js/services/prompts-service.js',
        'ApiToolsService': 'js/services/api-tools-service.js',
        'window.EncryptionService': 'js/services/encryption-service.js',
        'window.NamespaceService': 'js/services/namespace-service.js',
        'window.CoreStorageService': 'js/services/core-storage-service.js',
        'window.DataService': 'js/services/data-service.js',
        'window.StorageService': 'js/services/storage-service.js'
    };

    // Map of file paths to source code snippets
    const sourceCodeSnippets = {
        'js/services/storage-service.js': `/**
 * Storage Service
 * Main entry point for storage operations, using modular components
 */

window.StorageService = (function() {
    // Initialize the core storage service
    CoreStorageService.init();
    
    // Public API - expose all data service methods
    return {
        // Constants
        STORAGE_KEYS: NamespaceService.BASE_STORAGE_KEYS,
        BASE_STORAGE_KEYS: NamespaceService.BASE_STORAGE_KEYS,
        
        // Namespace methods
        getNamespace: NamespaceService.getNamespace,
        getNamespacedKey: NamespaceService.getNamespacedKey,
        resetNamespaceCache: NamespaceService.resetNamespaceCache,
        
        // Data methods
        saveApiKey: DataService.saveApiKey,
        getApiKey: DataService.getApiKey,
        saveModel: DataService.saveModel,
        getModel: DataService.getModel,
        saveChatHistory: DataService.saveChatHistory,
        loadChatHistory: DataService.loadChatHistory,
        clearChatHistory: DataService.clearChatHistory,
        saveSystemPrompt: DataService.saveSystemPrompt,
        getSystemPrompt: DataService.getSystemPrompt,
        saveShareOptions: DataService.saveShareOptions,
        getShareOptions: DataService.getShareOptions,
        saveBaseUrl: DataService.saveBaseUrl,
        getBaseUrl: DataService.getBaseUrl,
        saveBaseUrlProvider: DataService.saveBaseUrlProvider,
        getBaseUrlProvider: DataService.getBaseUrlProvider,
        getDefaultBaseUrlForProvider: DataService.getDefaultBaseUrlForProvider,
        saveTitle: DataService.saveTitle,
        getTitle: DataService.getTitle,
        saveSubtitle: DataService.saveSubtitle,
        getSubtitle: DataService.getSubtitle
    };
})();`,

        'js/services/encryption-service.js': `/**
 * Encryption Service
 * Handles encryption and decryption operations for secure storage
 */

window.EncryptionService = (function() {
    
    /**
     * Encrypt data with the given passphrase
     * @param {*} data - The data to encrypt
     * @param {string} passphrase - The passphrase to use for encryption
     * @returns {string} The encrypted data as a string
     */
    function encrypt(data, passphrase) {
        try {
            return CryptoUtils.encryptData(data, passphrase);
        } catch (error) {
            // Create error object with safe properties
            const errorInfo = {
                error: error.message,
                stack: error.stack,
                dataType: typeof data,
                dataIsArray: Array.isArray(data)
            };
            
            // Safely add length properties
            try {
                errorInfo.dataLength = data ? (typeof data === 'string' ? data.length : 0) : 0;
                if (typeof data === 'object' && data !== null) {
                    try {
                        const jsonStr = JSON.stringify(data);
                        errorInfo.jsonLength = jsonStr ? jsonStr.length : 0;
                    } catch (e) {
                        errorInfo.jsonError = e.message;
                    }
                }
                errorInfo.passphraseLength = passphrase ? passphrase.length : 0;
            } catch (e) {
                errorInfo.metadataError = e.message;
            }
            
            console.error('Encryption failed:', errorInfo);
            throw error;
        }
    }
    
    /**
     * Decrypt data with the given passphrase
     * @param {string} encryptedData - The encrypted data as a string
     * @param {string} passphrase - The passphrase to use for decryption
     * @returns {*} The decrypted data or null if decryption fails
     */
    function decrypt(encryptedData, passphrase) {
        try {
            const decryptedValue = CryptoUtils.decryptData(encryptedData, passphrase);
            
            if (decryptedValue === null) {
                // Create error object with safe properties
                const errorInfo = {
                    status: 'Decryption returned null'
                };
                
                // Safely add length properties
                try {
                    errorInfo.encryptedDataLength = encryptedData ? encryptedData.length : 0;
                    errorInfo.passphraseLength = passphrase ? passphrase.length : 0;
                    
                    if (passphrase) {
                        errorInfo.passphraseFirstChar = passphrase.charAt(0);
                        errorInfo.passphraseLastChar = passphrase.charAt(passphrase.length - 1);
                    }
                } catch (e) {
                    errorInfo.metadataError = e.message;
                }
                
                console.error('Decryption failed:', errorInfo);
            }
            
            return decryptedValue;
        } catch (error) {
            // Create error object with safe properties
            const errorInfo = {
                error: error.message,
                stack: error.stack
            };
            
            // Safely add length properties
            try {
                errorInfo.encryptedDataLength = encryptedData ? encryptedData.length : 0;
                errorInfo.passphraseLength = passphrase ? passphrase.length : 0;
            } catch (e) {
                errorInfo.metadataError = e.message;
            }
            
            console.error('Exception during decryption:', errorInfo);
            return null;
        }
    }
    
    /**
     * Initialize encryption system
     */
    function initEncryption() {
        // No initialization needed
    }
    
    // Public API
    return {
        encrypt: encrypt,
        decrypt: decrypt,
        initEncryption: initEncryption
    };
})();`,

        'js/utils/crypto-utils.js': `/**
 * Crypto Utilities
 * Provides encryption and decryption functionality using TweetNaCl
 */

window.CryptoUtils = (function() {
    // Constants
    const SALT_LENGTH = 16; // 16 bytes for salt
    const NONCE_LENGTH = nacl.box.nonceLength;
    const KEY_LENGTH = 32; // seed and secretKey length
    const KEY_ITERATIONS = 10000; // Number of iterations for key derivation
    const NAMESPACE_PREFIX = 'hackare_namespace_';
    const MASTER_KEY_PREFIX = 'hackare_master_key_';
    
    /**
     * Generate a SHA-256 hash of a string
     * @param {string} input - The string to hash
     * @returns {string} Hex string of the hash
     */
    function sha256(input) {
        // Convert input string to Uint8Array
        const inputBytes = nacl.util.decodeUTF8(input);
        
        // Use TweetNaCl's hash function (SHA-512) and take first 32 bytes (256 bits)
        const hashBytes = nacl.hash(inputBytes).slice(0, 32);
        
        // Convert to hex string
        return Array.from(hashBytes)
            .map(b => b.toString(16).padStart(2, '0'))
            .join('');
    }
    
    /**
     * Generate a random alphanumeric string of specified length
     * @param {number} length - The length of the string to generate
     * @returns {string} Random alphanumeric string
     */
    function generateRandomAlphaNum(length) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        const randomValues = nacl.randomBytes(length);
        
        for (let i = 0; i < length; i++) {
            // Use modulo to ensure we get a valid index for the chars string
            const randomIndex = randomValues[i] % chars.length;
            result += chars.charAt(randomIndex);
        }
        
        return result;
    }
    
    // Public API
    return {
        sha256,
        generateRandomAlphaNum,
        encryptData,
        decryptData,
        deriveKeyFromPassword,
        generateNamespaceKey
    };
})();`,

        'js/services/namespace-service.js': `/**
 * Namespace Service
 * Manages namespaces for storage isolation based on title/subtitle
 */

window.NamespaceService = (function() {
    // Base storage keys without namespace
    const BASE_STORAGE_KEYS = {
        API_KEY: 'api_key',
        MODEL: 'model',
        HISTORY: 'history',
        SYSTEM_PROMPT: 'system_prompt',
        SHARE_OPTIONS: 'share_options',
        BASE_URL: 'base_url',
        BASE_URL_PROVIDER: 'base_url_provider',
        TITLE: 'hackare_title',
        SUBTITLE: 'hackare_subtitle'
    };
    
    // Special keys that don't get namespaced (to avoid circular dependency)
    const NON_NAMESPACED_KEYS = [
        BASE_STORAGE_KEYS.TITLE,
        BASE_STORAGE_KEYS.SUBTITLE
    ];
    
    // Store the previous namespace when it changes
    let previousNamespaceId = null;
    let previousNamespaceKey = null;
    let previousNamespaceHash = null;
    
    // Current namespace - will be updated when title/subtitle change
    let currentNamespaceId = null;
    let currentNamespaceKey = null;
    let currentNamespaceHash = null;
    
    /**
     * Get the current namespace ID for storage keys
     * @returns {string} The namespace ID
     */
    function getNamespaceId() {
        return getOrCreateNamespace().namespaceId;
    }
    
    /**
     * Get the current namespace based on title and subtitle
     * @returns {string} The namespace ID
     */
    function getNamespace() {
        return getNamespaceId();
    }
    
    /**
     * Reset the namespace cache when title or subtitle changes
     */
    function resetNamespaceCache() {
        console.log('[CRYPTO DEBUG] Resetting namespace cache');
        
        // Store the current namespace before resetting
        if (currentNamespaceId && currentNamespaceKey && currentNamespaceHash) {
            previousNamespaceId = currentNamespaceId;
            previousNamespaceKey = currentNamespaceKey;
            previousNamespaceHash = currentNamespaceHash;
        }
        
        // Reset current namespace
        currentNamespaceId = null;
        currentNamespaceKey = null;
        currentNamespaceHash = null;
    }
    
    /**
     * Get the namespaced key for a storage item
     * @param {string} baseKey - The base key without namespace
     * @returns {string} The namespaced key
     */
    function getNamespacedKey(baseKey) {
        // Special keys don't get namespaced to avoid circular dependency
        if (NON_NAMESPACED_KEYS.includes(baseKey)) {
            return baseKey;
        }
        
        // Get the namespace ID
        const namespaceId = getNamespaceId();
        
        // Format: hackare_namespaceid_variablename
        return \`hackare_\${namespaceId}_\${baseKey}\`;
    }
    
    // Public API
    return {
        BASE_STORAGE_KEYS: BASE_STORAGE_KEYS,
        NON_NAMESPACED_KEYS: NON_NAMESPACED_KEYS,
        getNamespace: getNamespace,
        getNamespaceId: getNamespaceId,
        getNamespaceKey: getNamespaceKey,
        getPreviousNamespace: getPreviousNamespace,
        getPreviousNamespaceId: getPreviousNamespaceId,
        getPreviousNamespaceKey: getPreviousNamespaceKey,
        getPreviousNamespaceHash: getPreviousNamespaceHash,
        resetNamespaceCache: resetNamespaceCache,
        getNamespacedKey: getNamespacedKey,
        getKeysToReEncrypt: getKeysToReEncrypt,
        findExistingNamespace: findExistingNamespace,
        getMasterKey: getMasterKey
    };
})();`,

        'js/services/core-storage-service.js': `/**
 * Core Storage Service
 * Provides the core storage operations with encryption support
 */

window.CoreStorageService = (function() {
    // Flag to track initialization
    let initialized = false;
    
    /**
     * Initialize the core storage service
     */
    function init() {
        if (initialized) return;
        
        // Initialize encryption service if needed
        if (EncryptionService && typeof EncryptionService.initEncryption === 'function') {
            EncryptionService.initEncryption();
        }
        
        initialized = true;
    }
    
    /**
     * Set a value in storage with optional encryption
     * @param {string} baseKey - The base key without namespace
     * @param {*} value - The value to store
     * @param {boolean} encrypt - Whether to encrypt the value
     */
    function setValue(baseKey, value, encrypt = true) {
        try {
            // Get the namespaced key
            const key = NamespaceService.getNamespacedKey(baseKey);
            
            // Store the value
            if (value === null || value === undefined) {
                // Remove the item if value is null or undefined
                localStorage.removeItem(key);
                return;
            }
            
            // Convert value to string if needed
            let stringValue = typeof value === 'string' ? value : JSON.stringify(value);
            
            // Encrypt the value if needed
            if (encrypt) {
                const namespaceKey = NamespaceService.getNamespaceKey();
                if (!namespaceKey) {
                    console.error('No namespace key available for encryption');
                    return;
                }
                
                stringValue = EncryptionService.encrypt(stringValue, namespaceKey);
            }
            
            // Store the value
            localStorage.setItem(key, stringValue);
        } catch (error) {
            console.error('Failed to set value:', error);
        }
    }
    
    /**
     * Get a value from storage with optional decryption
     * @param {string} baseKey - The base key without namespace
     * @param {string} legacyKey - The legacy key to check if the namespaced key doesn't exist
     * @param {Function} migrateFn - Function to migrate the value from legacy to namespaced
     * @param {boolean} encrypted - Whether the value is encrypted
     * @returns {*} The value or null if not found
     */
    function getValue(baseKey, legacyKey, migrateFn, encrypted = true) {
        try {
            // Get the namespaced key
            const key = NamespaceService.getNamespacedKey(baseKey);
            
            // Try to get the value from the namespaced key
            let value = localStorage.getItem(key);
            
            // If not found and legacyKey is provided, try the legacy key
            if (value === null && legacyKey) {
                value = localStorage.getItem(legacyKey);
                
                // If found in legacy key, migrate it to the namespaced key
                if (value !== null && migrateFn) {
                    migrateFn(value);
                    
                    // Try to get the migrated value
                    value = localStorage.getItem(key);
                }
            }
            
            // If still not found, return null
            if (value === null) {
                return null;
            }
            
            // Decrypt the value if needed
            if (encrypted) {
                const namespaceKey = NamespaceService.getNamespaceKey();
                if (!namespaceKey) {
                    console.error('No namespace key available for decryption');
                    return null;
                }
                
                value = EncryptionService.decrypt(value, namespaceKey);
                
                // If decryption fails, return null
                if (value === null) {
                    return null;
                }
            }
            
            // Parse JSON if needed
            try {
                return JSON.parse(value);
            } catch (e) {
                // If parsing fails, return the string value
                return value;
            }
        } catch (error) {
            console.error('Failed to get value:', error);
            return null;
        }
    }
    
    // Public API
    return {
        init: init,
        setValue: setValue,
        getValue: getValue
    };
})();`,

        'js/services/data-service.js': `/**
 * Data Service
 * Implements specific data type operations
 */

window.DataService = (function() {
    // Get storage keys
    const STORAGE_KEYS = NamespaceService.BASE_STORAGE_KEYS;
    
    /**
     * Save API key
     * @param {string} apiKey - The API key to save
     */
    function saveApiKey(apiKey) {
        CoreStorageService.setValue(STORAGE_KEYS.API_KEY, apiKey);
    }
    
    /**
     * Get API key
     * @returns {string} The API key or null if not found
     */
    function getApiKey() {
        return CoreStorageService.getValue(
            STORAGE_KEYS.API_KEY, 
            STORAGE_KEYS.API_KEY, 
            saveApiKey
        );
    }
    
    /**
     * Save model
     * @param {string} model - The model to save
     */
    function saveModel(model) {
        CoreStorageService.setValue(STORAGE_KEYS.MODEL, model);
    }
    
    /**
     * Get model
     * @returns {string} The model or null if not found
     */
    function getModel() {
        return CoreStorageService.getValue(
            STORAGE_KEYS.MODEL, 
            STORAGE_KEYS.MODEL, 
            saveModel
        );
    }
    
    /**
     * Save chat history
     * @param {Array} history - The chat history to save
     */
    function saveChatHistory(history) {
        CoreStorageService.setValue(STORAGE_KEYS.HISTORY, history);
    }
    
    /**
     * Load chat history
     * @returns {Array} The chat history or empty array if not found
     */
    function loadChatHistory() {
        return CoreStorageService.getValue(
            STORAGE_KEYS.HISTORY, 
            STORAGE_KEYS.HISTORY, 
            saveChatHistory
        ) || [];
    }
    
    /**
     * Clear chat history
     */
    function clearChatHistory() {
        CoreStorageService.setValue(STORAGE_KEYS.HISTORY, []);
    }
    
    /**
     * Save system prompt
     * @param {string} systemPrompt - The system prompt to save
     */
    function saveSystemPrompt(systemPrompt) {
        CoreStorageService.setValue(STORAGE_KEYS.SYSTEM_PROMPT, systemPrompt);
    }
    
    /**
     * Get system prompt
     * @returns {string} The system prompt or null if not found
     */
    function getSystemPrompt() {
        return CoreStorageService.getValue(
            STORAGE_KEYS.SYSTEM_PROMPT, 
            STORAGE_KEYS.SYSTEM_PROMPT, 
            saveSystemPrompt
        );
    }
    
    /**
     * Save share options
     * @param {Object} options - The share options to save
     */
    function saveShareOptions(options) {
        CoreStorageService.setValue(STORAGE_KEYS.SHARE_OPTIONS, options);
    }
    
    /**
     * Get share options
     * @returns {Object} The share options or default options if not found
     */
    function getShareOptions() {
        return CoreStorageService.getValue(
            STORAGE_KEYS.SHARE_OPTIONS, 
            STORAGE_KEYS.SHARE_OPTIONS, 
            saveShareOptions
        ) || {
            includeApiKey: true,
            includeSystemPrompt: true,
            includeModel: true,
            includeConversation: false,
            messageCount: 1
        };
    }
    
    /**
     * Save base URL
     * @param {string} baseUrl - The base URL to save
     */
    function saveBaseUrl(baseUrl) {
        CoreStorageService.setValue(STORAGE_KEYS.BASE_URL, baseUrl);
    }
    
    /**
     * Get base URL
     * @returns {string} The base URL or default if not found
     */
    function getBaseUrl() {
        return CoreStorageService.getValue(
            STORAGE_KEYS.BASE_URL, 
            STORAGE_KEYS.BASE_URL, 
            saveBaseUrl
        ) || 'https://api.groq.com/openai/v1';
    }
    
    /**
     * Save base URL provider
     * @param {string} provider - The provider to save
     */
    function saveBaseUrlProvider(provider) {
        CoreStorageService.setValue(STORAGE_KEYS.BASE_URL_PROVIDER, provider);
    }
    
    /**
     * Get base URL provider
     * @returns {string} The provider or default if not found
     */
    function getBaseUrlProvider() {
        return CoreStorageService.getValue(
            STORAGE_KEYS.BASE_URL_PROVIDER, 
            STORAGE_KEYS.BASE_URL_PROVIDER, 
            saveBaseUrlProvider
        ) || 'groq';
    }
    
    /**
     * Get default base URL for provider
     * @param {string} provider - The provider
     * @returns {string} The default base URL for the provider
     */
    function getDefaultBaseUrlForProvider(provider) {
        const providers = {
            'groq': 'https://api.groq.com/openai/v1',
            'openai': 'https://api.openai.com/v1',
            'anthropic': 'https://api.anthropic.com/v1',
            'custom': ''
        };
        
        return providers[provider] || '';
    }
    
    /**
     * Save title
     * @param {string} title - The title to save
     */
    function saveTitle(title) {
        // Store in both localStorage and sessionStorage
        localStorage.setItem(STORAGE_KEYS.TITLE, title);
        sessionStorage.setItem(STORAGE_KEYS.TITLE, title);
        
        // Reset namespace cache when title changes
        NamespaceService.resetNamespaceCache();
    }
    
    /**
     * Get title
     * @returns {string} The title or default if not found
     */
    function getTitle() {
        // Try sessionStorage first, then localStorage
        let title = sessionStorage.getItem(STORAGE_KEYS.TITLE);
        if (!title) {
            title = localStorage.getItem(STORAGE_KEYS.TITLE);
            if (title) {
                // Update sessionStorage
                sessionStorage.setItem(STORAGE_KEYS.TITLE, title);
            }
        }
        
        return title || 'hacka.re';
    }
    
    /**
     * Save subtitle
     * @param {string} subtitle - The subtitle to save
     */
    function saveSubtitle(subtitle) {
        // Store in both localStorage and sessionStorage
        localStorage.setItem(STORAGE_KEYS.SUBTITLE, subtitle);
        sessionStorage.setItem(STORAGE_KEYS.SUBTITLE, subtitle);
        
        // Reset namespace cache when subtitle changes
        NamespaceService.resetNamespaceCache();
    }
    
    /**
     * Get subtitle
     * @returns {string} The subtitle or default if not found
     */
    function getSubtitle() {
        // Try sessionStorage first, then localStorage
        let subtitle = sessionStorage.getItem(STORAGE_KEYS.SUBTITLE);
        if (!subtitle) {
            subtitle = localStorage.getItem(STORAGE_KEYS.SUBTITLE);
            if (subtitle) {
                // Update sessionStorage
                sessionStorage.setItem(STORAGE_KEYS.SUBTITLE, subtitle);
            }
        }
        
        return subtitle || 'För hackare av hackare';
    }
    
    // Public API
    return {
        saveApiKey: saveApiKey,
        getApiKey: getApiKey,
        saveModel: saveModel,
        getModel: getModel,
        saveChatHistory: saveChatHistory,
        loadChatHistory: loadChatHistory,
        clearChatHistory: clearChatHistory,
        saveSystemPrompt: saveSystemPrompt,
        getSystemPrompt: getSystemPrompt,
        saveShareOptions: saveShareOptions,
        getShareOptions: getShareOptions,
        saveBaseUrl: saveBaseUrl,
        getBaseUrl: getBaseUrl,
        saveBaseUrlProvider: saveBaseUrlProvider,
        getBaseUrlProvider: getBaseUrlProvider,
        getDefaultBaseUrlForProvider: getDefaultBaseUrlForProvider,
        saveTitle: saveTitle,
        getTitle: getTitle,
        saveSubtitle: saveSubtitle,
        getSubtitle: getSubtitle
    };
})();`,

        'js/services/link-sharing-service.js': `/**
 * Link Sharing Service
 * Handles creation and parsing of encrypted shareable links
 */

window.LinkSharingService = (function() {
    /**
     * Create a shareable link with encrypted data
     * @param {Object} data - The data to include in the link
     * @param {string} sessionKey - The session key for encryption
     * @returns {string} The shareable link
     */
    function createShareableLink(data, sessionKey) {
        try {
            // Encrypt the data using the session key
            const encryptedData = CryptoUtils.encryptData(JSON.stringify(data), sessionKey);
            
            // Create the link with encrypted data in URL fragment
            const baseUrl = window.location.origin + window.location.pathname;
            return baseUrl + '#' + encodeURIComponent(encryptedData);
        } catch (error) {
            console.error('Error creating shareable link:', error);
            throw error;
        }
    }
    
    /**
     * Parse a shareable link and decrypt its data
     * @param {string} link - The shareable link
     * @param {string} sessionKey - The session key for decryption
     * @returns {Object} The decrypted data
     */
    function parseShareableLink(link, sessionKey) {
        try {
            // Extract encrypted data from URL fragment
            const urlParts = link.split('#');
            if (urlParts.length < 2) {
                throw new Error('Invalid shareable link format');
            }
            
            const encryptedData = decodeURIComponent(urlParts[1]);
            
            // Decrypt the data
            const decryptedData = CryptoUtils.decryptData(encryptedData, sessionKey);
            return JSON.parse(decryptedData);
        } catch (error) {
            console.error('Error parsing shareable link:', error);
            throw error;
        }
    }
    
    // Public API
    return {
        createShareableLink,
        parseShareableLink
    };
})();`,

        'js/services/share-service.js': `/**
 * Share Service
 * High-level facade for sharing operations
 */

window.ShareService = (function() {
    /**
     * Generate a shareable link with selected data
     * @param {Object} options - Sharing options
     * @returns {string} The shareable link
     */
    function generateShareableLink(options) {
        const shareData = {};
        
        // Include selected data based on options
        if (options.includeApiKey) {
            shareData.apiKey = StorageService.getApiKey();
        }
        
        if (options.includeBaseUrl) {
            shareData.baseUrl = StorageService.getBaseUrl();
        }
        
        if (options.includeModel) {
            shareData.model = StorageService.getModel();
        }
        
        if (options.includeSystemPrompt) {
            shareData.systemPrompt = StorageService.getSystemPrompt();
        }
        
        if (options.includeConversation && options.messageCount > 0) {
            const messages = StorageService.getChatHistory();
            shareData.conversation = messages.slice(-options.messageCount);
        }
        
        return LinkSharingService.createShareableLink(shareData, options.sessionKey);
    }
    
    // Public API
    return {
        generateShareableLink
    };
})();`,

        'js/services/prompts-service.js': `/**
 * Prompts Service
 * Handles storage and management of labeled prompts with encryption
 */

window.PromptsService = (function() {
    // Storage key for prompts
    const PROMPTS_STORAGE_KEY = 'prompts';
    const SELECTED_PROMPT_IDS_KEY = 'selected_prompt_ids';
    
    /**
     * Save a prompt to local storage with encryption
     * @param {Object} prompt - The prompt object to save
     * @returns {Object} The saved prompt
     */
    function savePrompt(prompt) {
        // Ensure prompt has an ID
        if (!prompt.id) {
            prompt.id = generateId();
        }
        
        // Get existing prompts
        const prompts = getPrompts();
        
        // Find if prompt already exists
        const existingIndex = prompts.findIndex(p => p.id === prompt.id);
        
        if (existingIndex >= 0) {
            prompts[existingIndex] = prompt;
        } else {
            prompts.push(prompt);
        }
        
        // Save to storage with encryption
        CoreStorageService.setValue(PROMPTS_STORAGE_KEY, prompts);
        return prompt;
    }
    
    /**
     * Get all prompts from local storage with decryption
     * @returns {Array} Array of prompt objects
     */
    function getPrompts() {
        const prompts = CoreStorageService.getValue(PROMPTS_STORAGE_KEY);
        return prompts || [];
    }
    
    /**
     * Get selected prompts
     * @returns {Array} Array of selected prompt objects
     */
    function getSelectedPrompts() {
        const selectedIds = getSelectedPromptIds();
        const allPrompts = getPrompts();
        return allPrompts.filter(prompt => selectedIds.includes(prompt.id));
    }
    
    // Public API
    return {
        savePrompt,
        getPrompts,
        getSelectedPrompts,
        togglePromptSelection,
        applySelectedPromptsAsSystem
    };
})();`,

        'js/services/api-tools-service.js': `/**
 * API Tools Service
 * Provides utilities for API interactions and tool calling
 */

window.ApiToolsService = (function() {
    /**
     * Format function definitions for API tool calling
     * @param {Array} functions - Array of function objects
     * @returns {Array} Formatted tool definitions
     */
    function formatToolDefinitions(functions) {
        return functions.map(func => ({
            type: 'function',
            function: {
                name: func.name,
                description: func.description || func.name,
                parameters: func.parameters || {
                    type: 'object',
                    properties: {},
                    required: []
                }
            }
        }));
    }
    
    /**
     * Execute a tool call
     * @param {Object} toolCall - The tool call object
     * @returns {Promise} Tool execution result
     */
    async function executeToolCall(toolCall) {
        const { name, arguments: args } = toolCall.function;
        
        // Find and execute the function
        if (window.FunctionToolsService) {
            return await window.FunctionToolsService.executeFunction(name, args);
        }
        
        throw new Error('Function execution service not available');
    }
    
    // Public API
    return {
        formatToolDefinitions,
        executeToolCall
    };
})();`
    };

    /**
     * Get the file path from a module name or path match
     * @param {string} match - The matched text
     * @returns {string} The file path
     */
    function getFilePathFromMatch(match) {
        // If it's already a path, return it
        if (match.includes('/')) {
            return match;
        }
        
        return moduleToFilePath[match] || null;
    }

    /**
     * Get source code snippet for a file path
     * @param {string} filePath - The path to the source file
     * @returns {string} The source code snippet
     */
    function getSourceCodeSnippet(filePath) {
        return sourceCodeSnippets[filePath] || null;
    }

    // Public API
    return {
        moduleToFilePath: moduleToFilePath,
        sourceCodeSnippets: sourceCodeSnippets,
        getFilePathFromMatch: getFilePathFromMatch,
        getSourceCodeSnippet: getSourceCodeSnippet
    };
})();
# hacka.re - Local Installation

## Quick Start

1. **Extract files**: Unzip all files to any directory on your computer
2. **Open in browser**: Double-click `index.html` or open it in any web browser
3. **Configure API**: Click the settings gear icon and enter your API details
4. **For Local LLMs**: See `about/local-llm-toolbox.html` for setup guides

## What's Included

- Complete hacka.re application (no internet required after setup)
- All JavaScript modules and services  
- CSS stylesheets and themes
- Local libraries (Font Awesome, syntax highlighting, etc.)
- Documentation and Local LLM setup guides

## Local LLM Setup

For complete privacy, combine with local LLMs:
- **Ollama**: `http://localhost:11434/v1/chat/completions`
- **LM Studio**: `http://localhost:1234/v1/chat/completions`
- **GPT4All**: `http://localhost:4891/v1/chat/completions`

See `about/local-llm-toolbox.html` for detailed setup instructions.

## Privacy & Security

- No backend server required
- All data stays in your browser's local storage
- Compatible with air-gapped systems when using local LLMs
- Encrypted storage for sensitive data

Generated: $(date)

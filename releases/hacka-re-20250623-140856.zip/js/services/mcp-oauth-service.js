/**
 * MCP OAuth Service for hacka.re
 * 
 * Provides OAuth 2.0 authorization code flow support for MCP connections.
 * Implements secure token management, PKCE, and automatic refresh.
 * 
 * Features:
 * - Authorization code flow with PKCE
 * - Secure token storage using encryption
 * - Automatic token refresh
 * - Multiple provider support
 * - No external dependencies
 */

/**
 * OAuth configuration for common providers
 */
const OAUTH_PROVIDERS = {
    github: {
        deviceCodeUrl: 'https://github.com/login/device/code',
        tokenUrl: 'https://github.com/login/oauth/access_token',
        scope: 'repo read:user',
        grantType: 'urn:ietf:params:oauth:grant-type:device_code',
        useDeviceFlow: true,
        // GitHub also supports authorization code flow, but we prefer device flow for client-side apps
        authorizationUrl: 'https://github.com/login/oauth/authorize',
        responseType: 'code'
    },
    google: {
        authorizationUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
        tokenUrl: 'https://oauth2.googleapis.com/token',
        scope: 'openid profile email',
        responseType: 'code',
        grantType: 'authorization_code'
    },
    custom: {
        authorizationUrl: '',
        tokenUrl: '',
        scope: '',
        responseType: 'code',
        grantType: 'authorization_code'
    }
};

/**
 * OAuth error class for specific OAuth-related errors
 */
class MCPOAuthError extends Error {
    constructor(message, code = null, data = null) {
        super(message);
        this.name = 'MCPOAuthError';
        this.code = code;
        this.data = data;
    }
}

/**
 * OAuth token class for managing token lifecycle
 */
class OAuthToken {
    constructor(tokenData) {
        this.accessToken = tokenData.access_token;
        this.tokenType = tokenData.token_type || 'Bearer';
        this.expiresIn = tokenData.expires_in;
        this.refreshToken = tokenData.refresh_token;
        this.scope = tokenData.scope;
        this.issuedAt = tokenData.issued_at || Date.now();
        this.idToken = tokenData.id_token; // For OpenID Connect
    }

    /**
     * Check if token is expired
     * @returns {boolean} True if token is expired
     */
    isExpired() {
        if (!this.expiresIn) {
            return false; // No expiry info, assume valid
        }
        const expiryTime = this.issuedAt + (this.expiresIn * 1000);
        // Add 60 second buffer to refresh before actual expiry
        return Date.now() > (expiryTime - 60000);
    }

    /**
     * Get remaining lifetime in seconds
     * @returns {number} Remaining lifetime in seconds, or -1 if no expiry
     */
    getRemainingLifetime() {
        if (!this.expiresIn) {
            return -1;
        }
        const expiryTime = this.issuedAt + (this.expiresIn * 1000);
        const remaining = Math.floor((expiryTime - Date.now()) / 1000);
        return Math.max(0, remaining);
    }

    /**
     * Convert to storage format
     * @returns {Object} Token data for storage
     */
    toJSON() {
        return {
            access_token: this.accessToken,
            token_type: this.tokenType,
            expires_in: this.expiresIn,
            refresh_token: this.refreshToken,
            scope: this.scope,
            issued_at: this.issuedAt,
            id_token: this.idToken
        };
    }
}

/**
 * PKCE (Proof Key for Code Exchange) helper
 */
class PKCEHelper {
    /**
     * Generate code verifier
     * @returns {string} Code verifier
     */
    static generateCodeVerifier() {
        const array = new Uint8Array(32);
        crypto.getRandomValues(array);
        return this.base64URLEncode(array);
    }

    /**
     * Generate code challenge from verifier
     * @param {string} verifier - Code verifier
     * @returns {Promise<string>} Code challenge
     */
    static async generateCodeChallenge(verifier) {
        const encoder = new TextEncoder();
        const data = encoder.encode(verifier);
        const digest = await crypto.subtle.digest('SHA-256', data);
        return this.base64URLEncode(new Uint8Array(digest));
    }

    /**
     * Base64 URL encode
     * @param {Uint8Array} buffer - Buffer to encode
     * @returns {string} Base64 URL encoded string
     */
    static base64URLEncode(buffer) {
        const base64 = btoa(String.fromCharCode(...buffer));
        return base64
            .replace(/\+/g, '-')
            .replace(/\//g, '_')
            .replace(/=/g, '');
    }
}

/**
 * OAuth service for managing OAuth flows and tokens
 */
class OAuthService {
    constructor() {
        this.storageService = window.CoreStorageService;
        this.tokens = new Map(); // In-memory cache
        this.pendingFlows = new Map(); // Track pending authorization flows
        this.serverConfigs = new Map(); // Server OAuth configurations
        this.STORAGE_KEY = 'mcp-oauth-tokens';
        this.PENDING_FLOWS_KEY = 'mcp-oauth-pending-flows';
        
        // Initialize metadata discovery and client registration services
        this.metadataService = null;
        this.registrationService = null;
        
        // Check if storage service is available before initializing
        if (this.storageService) {
            this.initializeServices();
            this.loadTokens();
            this.loadPendingFlows();
        } else {
            console.warn('[MCP OAuth] Storage service not available, deferring initialization');
            // Try again after a short delay
            setTimeout(() => {
                this.storageService = window.CoreStorageService;
                if (this.storageService) {
                    this.initializeServices();
                    this.loadTokens();
                    this.loadPendingFlows();
                }
            }, 100);
        }
    }

    /**
     * Initialize metadata discovery and client registration services
     */
    initializeServices() {
        if (window.MCPMetadataDiscovery) {
            this.metadataService = new window.MCPMetadataDiscovery.MetadataDiscoveryService();
        }
        if (window.MCPClientRegistration) {
            this.registrationService = new window.MCPClientRegistration.ClientRegistrationService();
        }
    }

    /**
     * Load tokens from encrypted storage
     */
    async loadTokens() {
        if (!this.storageService) {
            console.warn('[MCP OAuth] Storage service not available, skipping token loading');
            return;
        }
        
        try {
            const storedTokens = await this.storageService.getValue(this.STORAGE_KEY);
            if (storedTokens && typeof storedTokens === 'object') {
                Object.entries(storedTokens).forEach(([serverName, tokenData]) => {
                    this.tokens.set(serverName, new OAuthToken(tokenData));
                });
            }
        } catch (error) {
            console.error('[MCP OAuth] Failed to load tokens:', error);
        }
    }

    /**
     * Save tokens to encrypted storage
     */
    async saveTokens() {
        if (!this.storageService) {
            console.warn('[MCP OAuth] Storage service not available, skipping token saving');
            return;
        }
        
        try {
            const tokensObj = {};
            this.tokens.forEach((token, serverName) => {
                tokensObj[serverName] = token.toJSON();
            });
            await this.storageService.setValue(this.STORAGE_KEY, tokensObj);
        } catch (error) {
            console.error('[MCP OAuth] Failed to save tokens:', error);
        }
    }

    /**
     * Load pending flows from encrypted storage
     */
    async loadPendingFlows() {
        if (!this.storageService) {
            console.warn('[MCP OAuth] Storage service not available, skipping pending flows loading');
            return;
        }
        
        try {
            const storedFlows = await this.storageService.getValue(this.PENDING_FLOWS_KEY);
            if (storedFlows && typeof storedFlows === 'object') {
                Object.entries(storedFlows).forEach(([state, flowInfo]) => {
                    this.pendingFlows.set(state, flowInfo);
                });
                
                // Clean up old flows after loading
                this.cleanupPendingFlows();
            }
        } catch (error) {
            console.error('[MCP OAuth] Failed to load pending flows:', error);
        }
    }

    /**
     * Save pending flows to encrypted storage
     */
    async savePendingFlows() {
        if (!this.storageService) {
            console.warn('[MCP OAuth] Storage service not available, skipping pending flows saving');
            return;
        }
        
        try {
            const flowsObj = {};
            this.pendingFlows.forEach((flowInfo, state) => {
                flowsObj[state] = flowInfo;
            });
            await this.storageService.setValue(this.PENDING_FLOWS_KEY, flowsObj);
        } catch (error) {
            console.error('[MCP OAuth] Failed to save pending flows:', error);
        }
    }

    /**
     * Start OAuth Device Flow for GitHub (recommended for client-side apps)
     * @param {string} serverName - Name of the MCP server
     * @param {Object} config - OAuth configuration
     * @returns {Promise<Object>} Device code flow info
     */
    async startDeviceFlow(serverName, config) {
        try {
            console.log(`[MCP OAuth] Starting device flow for ${serverName}`);
            
            // Try automatic device code request first
            try {
                const deviceResponse = await fetch(config.deviceCodeUrl, {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({
                        client_id: config.clientId,
                        scope: config.scope || ''
                    })
                });
                
                if (!deviceResponse.ok) {
                    throw new Error(`Device code request failed: ${deviceResponse.status}`);
                }
                
                const deviceData = await deviceResponse.json();
                console.log(`[MCP OAuth] Device code obtained for ${serverName}`);
                
                return await this.createDeviceFlowInfo(serverName, config, deviceData);
                
            } catch (corsError) {
                console.log(`[MCP OAuth] Direct device flow request failed (likely CORS): ${corsError.message}`);
                
                // If CORS error, fall back to manual device flow
                if (corsError.message.includes('CORS') || corsError.message.includes('Failed to fetch')) {
                    console.log(`[MCP OAuth] Falling back to manual device flow for ${serverName}`);
                    return this.startManualDeviceFlow(serverName, config);
                }
                
                throw corsError;
            }
            
        } catch (error) {
            console.error(`[MCP OAuth] Failed to start device flow: ${error.message}`);
            throw new MCPOAuthError(
                `Device flow startup failed: ${error.message}`,
                'device_flow_start_failed'
            );
        }
    }
    
    /**
     * Create device flow info object
     * @param {string} serverName - Server name
     * @param {Object} config - OAuth config
     * @param {Object} deviceData - Device data from GitHub
     * @returns {Promise<Object>} Flow info
     */
    async createDeviceFlowInfo(serverName, config, deviceData) {
        const flowInfo = {
            serverName,
            config,
            deviceCode: deviceData.device_code,
            userCode: deviceData.user_code,
            verificationUri: deviceData.verification_uri,
            verificationUriComplete: deviceData.verification_uri_complete,
            expiresIn: deviceData.expires_in,
            interval: deviceData.interval || 5,
            startedAt: Date.now()
        };
        
        // Store in pending flows using device_code as key
        this.pendingFlows.set(deviceData.device_code, flowInfo);
        await this.savePendingFlows();
        
        return flowInfo;
    }
    
    /**
     * Start manual device flow when CORS prevents automatic flow
     * @param {string} serverName - Server name
     * @param {Object} config - OAuth config
     * @returns {Object} Manual flow info
     */
    startManualDeviceFlow(serverName, config) {
        // Generate a temporary ID for this manual flow
        const manualFlowId = 'manual_' + Date.now();
        console.log(`[MCP OAuth] Creating manual flow with ID: ${manualFlowId}`);
        
        const manualFlowInfo = {
            serverName,
            config,
            isManualFlow: true,
            manualFlowId,
            clientId: config.clientId,
            scope: config.scope || 'repo read:user',
            deviceCodeUrl: config.deviceCodeUrl,
            verificationUri: 'https://github.com/login/device',
            startedAt: Date.now()
        };
        
        // Store manual flow
        this.pendingFlows.set(manualFlowId, manualFlowInfo);
        console.log(`[MCP OAuth] Stored manual flow. Pending flows count: ${this.pendingFlows.size}`);
        console.log(`[MCP OAuth] Pending flows keys:`, Array.from(this.pendingFlows.keys()));
        this.savePendingFlows();
        
        return manualFlowInfo;
    }

    /**
     * Handle manual device flow data entry
     * @param {string} manualFlowId - Manual flow ID
     * @param {Object} deviceData - Device data entered by user
     * @returns {Object} Flow info with device data
     */
    async submitManualDeviceData(manualFlowId, deviceData) {
        console.log(`[MCP OAuth] Looking for manual flow with ID: ${manualFlowId}`);
        console.log(`[MCP OAuth] Available flows:`, Array.from(this.pendingFlows.keys()));
        console.log(`[MCP OAuth] Pending flows size: ${this.pendingFlows.size}`);
        
        const manualFlow = this.pendingFlows.get(manualFlowId);
        console.log(`[MCP OAuth] Found manual flow:`, manualFlow);
        
        if (!manualFlow || !manualFlow.isManualFlow) {
            throw new Error(`Invalid manual flow ID: ${manualFlowId}`);
        }
        
        // Convert manual flow to regular device flow
        const flowInfo = await this.createDeviceFlowInfo(
            manualFlow.serverName,
            manualFlow.config,
            deviceData
        );
        
        // Remove the manual flow
        this.pendingFlows.delete(manualFlowId);
        await this.savePendingFlows();
        
        return flowInfo;
    }
    
    /**
     * Poll for device flow completion
     * @param {string} deviceCode - Device code from startDeviceFlow
     * @returns {Promise<Object>} Token response when complete
     */
    async pollDeviceFlow(deviceCode) {
        const flowInfo = this.pendingFlows.get(deviceCode);
        if (!flowInfo) {
            throw new MCPOAuthError('Device flow not found', 'device_flow_not_found');
        }
        
        const { serverName, config } = flowInfo;
        
        try {
            const response = await fetch(config.tokenUrl, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    client_id: config.clientId,
                    device_code: deviceCode,
                    grant_type: config.grantType
                })
            });
            
            const data = await response.json();
            
            if (data.error) {
                if (data.error === 'authorization_pending') {
                    // User hasn't completed authorization yet
                    return { pending: true, interval: flowInfo.interval };
                } else if (data.error === 'slow_down') {
                    // Increase polling interval
                    flowInfo.interval = Math.min(flowInfo.interval * 2, 30);
                    return { pending: true, interval: flowInfo.interval };
                } else if (data.error === 'expired_token') {
                    // Device code expired
                    this.pendingFlows.delete(deviceCode);
                    await this.savePendingFlows();
                    throw new MCPOAuthError('Device code expired', 'device_code_expired');
                } else if (data.error === 'access_denied') {
                    // User denied access
                    this.pendingFlows.delete(deviceCode);
                    await this.savePendingFlows();
                    throw new MCPOAuthError('Access denied by user', 'access_denied');
                } else {
                    throw new MCPOAuthError(`Device flow error: ${data.error}`, data.error);
                }
            }
            
            // Success! Create and store token
            data.issued_at = Date.now();
            const token = new OAuthToken(data);
            this.tokens.set(serverName, token);
            await this.saveTokens();
            
            // Clean up pending flow
            this.pendingFlows.delete(deviceCode);
            await this.savePendingFlows();
            
            console.log(`[MCP OAuth] Device flow completed for ${serverName}`);
            return { token, serverName };
            
        } catch (error) {
            if (error instanceof MCPOAuthError) throw error;
            
            // If this is a CORS error for GitHub, provide helpful manual instructions
            if ((error.message.includes('CORS') || error.message.includes('Failed to fetch')) && 
                config && (config.provider === 'github' || config.useDeviceFlow)) {
                console.log('[MCP OAuth] GitHub token polling blocked by CORS - suggesting manual token entry');
                throw new MCPOAuthError(
                    'GitHub token polling blocked by CORS. Please enter your access token manually.',
                    'github_cors_polling_failed',
                    {
                        requiresManualToken: true,
                        serverName,
                        deviceCode,
                        clientId: config.clientId,
                        tokenInstructions: `After authorizing on GitHub, run this command to get your token:\n\ncurl -X POST https://github.com/login/oauth/access_token -H "Accept: application/json" -d "client_id=${config.clientId}&device_code=${deviceCode}&grant_type=urn:ietf:params:oauth:grant-type:device_code"`
                    }
                );
            }
            
            throw new MCPOAuthError(`Device flow polling failed: ${error.message}`, 'device_flow_poll_failed');
        }
    }

    /**
     * Store manually entered token (for CORS workarounds)
     * @param {string} serverName - Server name
     * @param {Object} tokenData - Token data
     */
    async storeManualToken(serverName, tokenData) {
        console.log(`[MCP OAuth] Storing manual token for ${serverName}`);
        
        const token = new OAuthToken(tokenData);
        this.tokens.set(serverName, token);
        await this.saveTokens();
        
        console.log(`[MCP OAuth] Manual token stored successfully for ${serverName}`);
    }
    
    /**
     * Start OAuth authorization flow with automatic metadata discovery and client registration
     * @param {string} serverName - Name of the MCP server
     * @param {Object} config - OAuth configuration
     * @returns {Promise<Object>} Authorization URL and flow info
     */
    async startAuthorizationFlow(serverName, config) {
        try {
            // Step 1: Discover OAuth server metadata if MCP server URL provided
            let effectiveConfig = { ...config };
            if (config.mcpServerUrl && !config.skipMetadataDiscovery && this.metadataService) {
                console.log(`[MCP OAuth] Discovering metadata for ${serverName}`);
                try {
                    const metadata = await this.metadataService.discoverMetadata(
                        config.mcpServerUrl,
                        config.mcpProtocolVersion || '2024-11-05'
                    );
                    
                    // Update config with discovered endpoints
                    effectiveConfig.authorizationUrl = metadata.authorization_endpoint;
                    effectiveConfig.tokenUrl = metadata.token_endpoint;
                    effectiveConfig.registrationEndpoint = metadata.registration_endpoint;
                    effectiveConfig._metadata = metadata;
                    
                    console.log('[MCP OAuth] Metadata discovery successful');
                } catch (metadataError) {
                    console.warn(`[MCP OAuth] Metadata discovery failed: ${metadataError.message}`);
                    // Continue with provided config
                }
            }
            
            // Step 2: Register client if registration endpoint is available
            if (effectiveConfig.registrationEndpoint && !config.skipClientRegistration && this.registrationService) {
                console.log(`[MCP OAuth] Attempting client registration for ${serverName}`);
                try {
                    const clientCredentials = await this.registrationService.registerClient(
                        serverName,
                        effectiveConfig.registrationEndpoint,
                        {
                            clientName: config.clientName || `hacka.re MCP Client (${serverName})`,
                            clientUri: config.clientUri || 'https://hacka.re',
                            scope: effectiveConfig.scope,
                            customRedirectUri: config.redirectUri
                        }
                    );
                    
                    // Update config with registered client credentials
                    effectiveConfig.clientId = clientCredentials.client_id;
                    effectiveConfig.clientSecret = clientCredentials.client_secret;
                    effectiveConfig.redirectUri = clientCredentials.redirect_uris[0];
                    effectiveConfig._clientCredentials = clientCredentials;
                    
                    console.log('[MCP OAuth] Client registration successful');
                } catch (registrationError) {
                    console.warn(`[MCP OAuth] Client registration failed: ${registrationError.message}`);
                    // Continue with provided credentials
                }
            }
            
            // Store the effective configuration
            this.serverConfigs.set(serverName, effectiveConfig);
            
            // Step 3: Generate PKCE values (OAuth 2.1 requirement)
            const codeVerifier = PKCEHelper.generateCodeVerifier();
            const codeChallenge = await PKCEHelper.generateCodeChallenge(codeVerifier);
        
            // Generate state for CSRF protection with session information encoded
            const baseState = PKCEHelper.generateCodeVerifier();
            const namespaceId = window.NamespaceService ? window.NamespaceService.getNamespaceId() : 'default';
            
            // Get session key for state encoding (needed for session restoration on callback)
            const sessionKey = window.ShareManager && window.ShareManager.getSessionKey ? 
                window.ShareManager.getSessionKey() : null;
            
            // Encode session information into state parameter since GitHub strips query params
            let state;
            if (sessionKey) {
                // Encode session key into state: baseState:namespace:sessionKey
                const encodedSession = btoa(sessionKey).replace(/[+/=]/g, ''); // Remove URL-unsafe chars
                state = `${baseState}:${namespaceId}:${encodedSession}`;
                console.log(`[MCP OAuth] State includes session key for automatic restoration`);
            } else {
                // Just include namespace: baseState:namespace
                state = `${baseState}:${namespaceId}`;
                console.log(`[MCP OAuth] State includes namespace only - will prompt for session key`);
            }
            
            // Use base redirect URI since GitHub strips query parameters anyway
            const enhancedRedirectUri = effectiveConfig.redirectUri;
            console.log(`[MCP OAuth] Using base redirect URI (GitHub strips query params): ${enhancedRedirectUri}`);
            
            // Build authorization URL with enhanced redirect URI
            console.log(`[MCP OAuth] Building params with redirect_uri: ${enhancedRedirectUri}`);
            const params = new URLSearchParams({
                response_type: effectiveConfig.responseType || 'code',
                client_id: effectiveConfig.clientId,
                redirect_uri: enhancedRedirectUri,
                scope: effectiveConfig.scope,
                state: state,
                code_challenge: codeChallenge,
                code_challenge_method: 'S256'
            });
            
            console.log(`[MCP OAuth] URLSearchParams redirect_uri: ${params.get('redirect_uri')}`);

            // Add custom parameters if provided
            if (effectiveConfig.additionalParams) {
                Object.entries(effectiveConfig.additionalParams).forEach(([key, value]) => {
                    params.set(key, value);
                });
            }

            const authorizationUrl = `${effectiveConfig.authorizationUrl}?${params.toString()}`;
            console.log(`[MCP OAuth] Final authorization URL: ${authorizationUrl}`);
            
            // Store flow information including the enhanced redirect URI
            const flowInfo = {
                serverName,
                config: effectiveConfig,
                state,
                codeVerifier,
                codeChallenge,
                enhancedRedirectUri: enhancedRedirectUri, // Store the exact redirect URI used
                startedAt: Date.now()
            };
            
            this.pendingFlows.set(state, flowInfo);
            
            // Save pending flows to storage immediately
            await this.savePendingFlows();
            
            // Clean up old flows (older than 10 minutes)
            this.cleanupPendingFlows();
            
            console.log(`[MCP OAuth] Authorization flow started for ${serverName}, state: ${state}`);
            return {
                authorizationUrl,
                state,
                serverName,
                metadata: effectiveConfig._metadata,
                clientCredentials: effectiveConfig._clientCredentials
            };
            
        } catch (error) {
            console.error(`[MCP OAuth] Failed to start authorization flow: ${error.message}`);
            throw new MCPOAuthError(
                `Authorization flow startup failed: ${error.message}`,
                'flow_start_failed'
            );
        }
    }

    /**
     * Complete OAuth authorization flow
     * @param {string} code - Authorization code
     * @param {string} state - State parameter
     * @returns {Promise<OAuthToken>} OAuth token
     */
    async completeAuthorizationFlow(code, state) {
        // Extract namespace from state parameter: baseState:namespaceId or baseState:namespaceId:encodedSessionKey
        const stateParts = state.split(':');
        const baseState = stateParts[0];
        const namespaceId = stateParts[1];
        const encodedSessionKey = stateParts[2]; // Optional
        
        // If we have a namespace, try to restore session context
        if (namespaceId && window.NamespaceService) {
            const currentNamespaceId = window.NamespaceService.getNamespaceId();
            console.log(`[MCP OAuth] Callback state namespace: ${namespaceId}, current: ${currentNamespaceId}`);
            
            // If namespaces don't match, the user might need to re-enter their session
            if (currentNamespaceId !== namespaceId) {
                console.warn(`[MCP OAuth] Namespace mismatch - callback: ${namespaceId}, current: ${currentNamespaceId}`);
                // We'll still try to complete the flow, but this might indicate a session issue
            }
        }
        
        console.log(`[MCP OAuth] Looking for pending flow with state: ${state}`);
        console.log(`[MCP OAuth] Available pending flows:`, Array.from(this.pendingFlows.keys()));
        
        const flowInfo = this.pendingFlows.get(state);
        if (!flowInfo) {
            console.error(`[MCP OAuth] No pending flow found for state: ${state}`);
            console.error(`[MCP OAuth] Pending flows in memory:`, this.pendingFlows.size);
            
            // Try to reload pending flows from storage
            await this.loadPendingFlows();
            console.log(`[MCP OAuth] After reloading, available flows:`, Array.from(this.pendingFlows.keys()));
            
            const reloadedFlowInfo = this.pendingFlows.get(state);
            if (!reloadedFlowInfo) {
                throw new MCPOAuthError(
                    'Invalid or expired state parameter. This may happen if your session has changed since starting the OAuth flow.', 
                    'invalid_state'
                );
            }
        }
        
        // Get the flow info (either from initial lookup or after reload)
        const finalFlowInfo = this.pendingFlows.get(state);
        if (!finalFlowInfo) {
            throw new MCPOAuthError(
                'Invalid or expired state parameter. This may happen if your session has changed since starting the OAuth flow.', 
                'invalid_state'
            );
        }
        
        this.pendingFlows.delete(state);
        
        // Save updated pending flows to storage
        await this.savePendingFlows();
        
        const { serverName, config, codeVerifier, enhancedRedirectUri } = finalFlowInfo;
        
        // Exchange code for token using the exact redirect URI that was used in authorization
        const tokenData = await this.exchangeCodeForToken(code, config, codeVerifier, enhancedRedirectUri);
        
        // Create and store token
        const token = new OAuthToken(tokenData);
        this.tokens.set(serverName, token);
        await this.saveTokens();
        
        console.log(`[MCP OAuth] Successfully obtained token for ${serverName}`);
        
        return { token, serverName };
    }

    /**
     * Exchange authorization code for access token
     * @param {string} code - Authorization code
     * @param {Object} config - OAuth configuration
     * @param {string} codeVerifier - PKCE code verifier
     * @param {string} redirectUri - The exact redirect URI used in authorization (optional)
     * @returns {Promise<Object>} Token response
     */
    async exchangeCodeForToken(code, config, codeVerifier, redirectUri = null) {
        // Use the provided redirect URI or fall back to config.redirectUri
        const actualRedirectUri = redirectUri || config.redirectUri;
        console.log(`[MCP OAuth] Token exchange using redirect_uri: ${actualRedirectUri}`);
        
        const params = new URLSearchParams({
            grant_type: config.grantType || 'authorization_code',
            code: code,
            redirect_uri: actualRedirectUri,
            client_id: config.clientId,
            code_verifier: codeVerifier
        });

        // Add client secret if provided (for confidential clients)
        if (config.clientSecret) {
            params.set('client_secret', config.clientSecret);
        }

        console.log(`[MCP OAuth] Token exchange URL: ${config.tokenUrl}`);

        const response = await fetch(config.tokenUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/json'
            },
            body: params.toString()
        });

        if (!response.ok) {
            const error = await response.json().catch(() => ({ error: 'token_exchange_failed' }));
            throw new MCPOAuthError(
                'Failed to exchange code for token',
                error.error,
                error.error_description
            );
        }

        const tokenData = await response.json();
        tokenData.issued_at = Date.now();
        
        return tokenData;
    }

    /**
     * Refresh access token
     * @param {string} serverName - Name of the MCP server
     * @returns {Promise<OAuthToken>} New OAuth token
     */
    async refreshAccessToken(serverName) {
        const token = this.tokens.get(serverName);
        if (!token || !token.refreshToken) {
            throw new MCPOAuthError('No refresh token available', 'no_refresh_token');
        }

        const config = this.getServerConfig(serverName);
        if (!config) {
            throw new MCPOAuthError('Server configuration not found', 'config_not_found');
        }

        const params = new URLSearchParams({
            grant_type: 'refresh_token',
            refresh_token: token.refreshToken,
            client_id: config.clientId
        });

        if (config.clientSecret) {
            params.set('client_secret', config.clientSecret);
        }

        const response = await fetch(config.tokenUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/json'
            },
            body: params.toString()
        });

        if (!response.ok) {
            const error = await response.json().catch(() => ({ error: 'refresh_failed' }));
            throw new MCPOAuthError(
                'Failed to refresh token',
                error.error,
                error.error_description
            );
        }

        const tokenData = await response.json();
        tokenData.issued_at = Date.now();
        
        // Preserve refresh token if not included in response
        if (!tokenData.refresh_token && token.refreshToken) {
            tokenData.refresh_token = token.refreshToken;
        }

        const newToken = new OAuthToken(tokenData);
        this.tokens.set(serverName, newToken);
        await this.saveTokens();

        console.log(`[MCP OAuth] Successfully refreshed token for ${serverName}`);
        
        return newToken;
    }

    /**
     * Get access token for server
     * @param {string} serverName - Name of the MCP server
     * @param {boolean} autoRefresh - Automatically refresh if expired
     * @returns {Promise<string>} Access token
     */
    async getAccessToken(serverName, autoRefresh = true) {
        let token = this.tokens.get(serverName);
        
        if (!token) {
            throw new MCPOAuthError('No token found for server', 'no_token');
        }

        if (autoRefresh && token.isExpired() && token.refreshToken) {
            try {
                token = await this.refreshAccessToken(serverName);
            } catch (error) {
                console.error(`[MCP OAuth] Failed to refresh token for ${serverName}:`, error);
                throw error;
            }
        }

        return token.accessToken;
    }

    /**
     * Get token info for server
     * @param {string} serverName - Name of the MCP server
     * @returns {Object|null} Token info or null
     */
    getTokenInfo(serverName) {
        const token = this.tokens.get(serverName);
        if (!token) {
            return null;
        }

        return {
            hasToken: true,
            isExpired: token.isExpired(),
            remainingLifetime: token.getRemainingLifetime(),
            scope: token.scope,
            tokenType: token.tokenType,
            hasRefreshToken: !!token.refreshToken
        };
    }

    /**
     * Revoke token for server
     * @param {string} serverName - Name of the MCP server
     */
    async revokeToken(serverName) {
        this.tokens.delete(serverName);
        await this.saveTokens();
        console.log(`[MCP OAuth] Revoked token for ${serverName}`);
    }

    /**
     * Get server configuration
     * @param {string} serverName - Name of the MCP server
     * @returns {Object|null} Server OAuth configuration
     */
    getServerConfig(serverName) {
        // Check if we have a stored configuration
        if (this.serverConfigs && this.serverConfigs.has(serverName)) {
            return this.serverConfigs.get(serverName);
        }
        
        // Try to get from OAuth config component if available
        if (window.mcpOAuthConfig) {
            return window.mcpOAuthConfig.getConfiguration(serverName);
        }
        
        return null;
    }

    /**
     * Clean up old pending flows
     */
    async cleanupPendingFlows() {
        const tenMinutesAgo = Date.now() - (10 * 60 * 1000);
        let hasChanges = false;
        
        for (const [state, flowInfo] of this.pendingFlows) {
            if (flowInfo.startedAt < tenMinutesAgo) {
                this.pendingFlows.delete(state);
                hasChanges = true;
                console.log(`[MCP OAuth] Cleaned up expired pending flow: ${state}`);
            }
        }
        
        // Save to storage if we made changes
        if (hasChanges) {
            await this.savePendingFlows();
        }
    }

    /**
     * Handle OAuth redirect
     * @param {string} url - Redirect URL with parameters
     * @returns {Promise<Object>} Result of handling redirect
     */
    async handleRedirect(url) {
        const urlObj = new URL(url);
        const params = urlObj.searchParams;
        
        // Check for error response
        const error = params.get('error');
        if (error) {
            throw new MCPOAuthError(
                'OAuth authorization failed',
                error,
                params.get('error_description')
            );
        }
        
        // Extract code and state
        const code = params.get('code');
        const state = params.get('state');
        
        if (!code || !state) {
            throw new MCPOAuthError('Missing code or state parameter', 'invalid_response');
        }
        
        // Complete the flow
        const token = await this.completeAuthorizationFlow(code, state);
        
        return {
            success: true,
            serverName: this.pendingFlows.get(state)?.serverName,
            token
        };
    }

    /**
     * Build authorization header
     * @param {string} serverName - Name of the MCP server
     * @returns {Promise<Object>} Authorization header
     */
    async getAuthorizationHeader(serverName) {
        const token = await this.getAccessToken(serverName);
        const tokenInfo = this.tokens.get(serverName);
        
        return {
            'Authorization': `${tokenInfo.tokenType} ${token}`
        };
    }

    /**
     * Get comprehensive server information including metadata and client credentials
     * @param {string} serverName - Name of the MCP server
     * @returns {Promise<Object|null>} Complete server information
     */
    async getServerInfo(serverName) {
        const config = this.serverConfigs.get(serverName);
        const tokenInfo = this.getTokenInfo(serverName);
        const clientCredentials = this.registrationService ? 
            await this.registrationService.getClientCredentials(serverName) : null;
        
        return {
            serverName,
            config,
            tokenInfo,
            clientCredentials,
            hasMetadata: !!(config && config._metadata),
            hasClientRegistration: !!clientCredentials,
            isAuthenticated: !!(tokenInfo && tokenInfo.hasToken && !tokenInfo.isExpired)
        };
    }

    /**
     * Validate OAuth 2.1 compliance for a server
     * @param {string} serverName - Name of the MCP server
     * @returns {Promise<Object>} Compliance report
     */
    async validateOAuth21Compliance(serverName) {
        const config = this.serverConfigs.get(serverName);
        if (!config || !config._metadata) {
            return {
                compatible: false,
                error: 'No metadata available for compliance check'
            };
        }

        return this.metadataService ? 
            this.metadataService.validateOAuth21Compatibility(config._metadata) :
            { compatible: false, error: 'Metadata service not available' };
    }

    /**
     * Update client registration
     * @param {string} serverName - Name of the MCP server
     * @param {Object} updates - Updates to apply
     * @returns {Promise<Object>} Updated registration
     */
    async updateClientRegistration(serverName, updates) {
        if (!this.registrationService) {
            throw new MCPOAuthError('Client registration service not available', 'service_unavailable');
        }

        const updatedCredentials = await this.registrationService.updateClientRegistration(
            serverName,
            updates
        );
        
        // Update stored config if we have one
        const config = this.serverConfigs.get(serverName);
        if (config) {
            config._clientCredentials = updatedCredentials;
            config.clientId = updatedCredentials.client_id;
            config.clientSecret = updatedCredentials.client_secret;
            this.serverConfigs.set(serverName, config);
        }
        
        return updatedCredentials;
    }

    /**
     * Delete client registration and revoke tokens
     * @param {string} serverName - Name of the MCP server
     * @returns {Promise<void>}
     */
    async deleteServerRegistration(serverName) {
        // Revoke tokens first
        await this.revokeToken(serverName);
        
        // Delete client registration if service available
        if (this.registrationService) {
            await this.registrationService.deleteClientRegistration(serverName);
        }
        
        // Clean up local state
        this.serverConfigs.delete(serverName);
        
        console.log(`[MCP OAuth] Deleted registration for ${serverName}`);
    }

    /**
     * List all configured servers with their status
     * @returns {Promise<Array<Object>>} Array of server information
     */
    async listServers() {
        const servers = [];
        
        // Get all servers from configs
        for (const serverName of this.serverConfigs.keys()) {
            servers.push(await this.getServerInfo(serverName));
        }
        
        // Get servers that only have client registrations
        if (this.registrationService) {
            const registeredClients = await this.registrationService.listRegisteredClients();
            for (const client of registeredClients) {
                if (!this.serverConfigs.has(client.serverName)) {
                    servers.push({
                        serverName: client.serverName,
                        config: null,
                        tokenInfo: this.getTokenInfo(client.serverName),
                        clientCredentials: await this.registrationService.getClientCredentials(client.serverName),
                        hasMetadata: false,
                        hasClientRegistration: true,
                        isAuthenticated: false
                    });
                }
            }
        }
        
        return servers;
    }

    /**
     * Enhanced PKCE helper using TweetNaCl for additional entropy
     * @returns {string} Secure code verifier
     */
    static generateSecureCodeVerifier() {
        // Use TweetNaCl for additional entropy if available
        if (window.CryptoUtils) {
            return window.CryptoUtils.generateRandomAlphaNum(128);
        }
        return PKCEHelper.generateCodeVerifier();
    }
}

// Export service
window.MCPOAuthService = {
    OAuthService,
    OAuthToken,
    PKCEHelper,
    MCPOAuthError,
    OAUTH_PROVIDERS
};
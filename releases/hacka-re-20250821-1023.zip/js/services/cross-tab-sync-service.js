/**
 * Cross-Tab Synchronization Service
 * 
 * Handles synchronization of conversation data across multiple tabs
 * for the same shared link namespace. Uses localStorage events
 * and a queue system to ensure all tabs stay in sync.
 */

window.CrossTabSyncService = (function() {
    let isInitialized = false;
    let syncQueue = [];
    let lastKnownHistoryHash = null;
    let lastReloadTime = 0; // Track last reload to prevent rapid successive reloads
    let syncCheckInterval = null;
    let consecutiveEmptyChecks = 0; // Track empty hash checks to reduce frequency
    let isReloading = false; // Track if we're currently reloading to prevent loops
    
    // Constants
    const SYNC_CHECK_INTERVAL = 5000; // Check every 5 seconds (reduced frequency)
    const SYNC_TRIGGER_KEY = 'hackare_sync_trigger';     // Properly prefixed
    const HISTORY_HASH_KEY = 'hackare_history_hash';    // Properly prefixed for cross-tab sync
    const TAB_HEARTBEAT_KEY = 'hackare_tab_heartbeat';   // For detecting multiple tabs
    const TAB_ID = Date.now() + '_' + Math.random();     // Unique ID for this tab
    
    /**
     * Initialize cross-tab synchronization
     * Only active for shared links (localStorage mode)
     */
    function init() {
        if (isInitialized) {
            return;
        }
        
        console.log('[CrossTabSync] Initializing cross-tab synchronization...');
        
        // Only enable for shared links (localStorage mode)
        if (!StorageTypeService || !StorageTypeService.isUsingLocalStorage()) {
            console.log('[CrossTabSync] Not using localStorage - cross-tab sync disabled');
            return;
        }
        
        isInitialized = true;
        
        // Listen for storage events from other tabs
        window.addEventListener('storage', handleStorageEvent);
        
        // Don't start periodic sync check - only respond to explicit events
        // This prevents self-triggering loops
        
        // Initialize history hash but don't update localStorage yet
        // Wait for content to stabilize
        setTimeout(() => {
            lastKnownHistoryHash = getHistoryHash();
            console.log('[CrossTabSync] Initial history hash:', lastKnownHistoryHash);
        }, 2000);
        
        console.log('[CrossTabSync] Cross-tab synchronization initialized (event-driven mode only)');
        console.log('[CrossTabSync] Tab ID:', TAB_ID);
    }
    
    /**
     * Handle localStorage events from other tabs
     * @param {StorageEvent} event - The storage event
     */
    function handleStorageEvent(event) {
        // Only handle our sync events
        if (event.key !== SYNC_TRIGGER_KEY && event.key !== HISTORY_HASH_KEY) {
            return;
        }
        
        // Storage events only fire in OTHER tabs, not the tab that set the value
        // So this is always from another tab
        console.log('[CrossTabSync] Storage event from another tab:', event.key);
        
        if (event.key === SYNC_TRIGGER_KEY) {
            // Another tab triggered a sync
            handleSyncTrigger(event.newValue);
        } else if (event.key === HISTORY_HASH_KEY) {
            // History hash changed in another tab  
            handleHistoryHashChange(event.newValue);
        }
    }
    
    /**
     * Handle sync trigger from another tab
     * @param {string} triggerData - JSON string with sync information
     */
    function handleSyncTrigger(triggerData) {
        if (!triggerData) return;
        
        try {
            const data = JSON.parse(triggerData);
            const { type, timestamp, namespaceId, tabId } = data;
            
            // Ignore our own events (shouldn't happen but extra safety)
            if (tabId === TAB_ID) {
                console.log('[CrossTabSync] Ignoring our own sync trigger');
                return;
            }
            
            // Only sync if it's for our namespace
            const currentNamespace = NamespaceService ? NamespaceService.getNamespaceId() : null;
            if (namespaceId && currentNamespace && namespaceId !== currentNamespace) {
                console.log('[CrossTabSync] Ignoring sync for different namespace:', namespaceId);
                return;
            }
            
            console.log('[CrossTabSync] Processing sync trigger from tab:', tabId, 'type:', type);
            
            // Add to sync queue
            syncQueue.push({
                type,
                timestamp,
                namespaceId,
                tabId
            });
            
            // Process queue
            processSyncQueue();
            
        } catch (error) {
            console.error('[CrossTabSync] Error handling sync trigger:', error);
        }
    }
    
    /**
     * Handle history hash change from another tab
     * @param {string} newHash - New history hash
     */
    function handleHistoryHashChange(newHash) {
        // Parse the hash data if it's JSON
        let hashData = newHash;
        let sourceTabId = null;
        
        try {
            const parsed = JSON.parse(newHash);
            if (parsed.hash && parsed.tabId) {
                hashData = parsed.hash;
                sourceTabId = parsed.tabId;
                
                // Ignore our own hash updates
                if (sourceTabId === TAB_ID) {
                    console.log('[CrossTabSync] Ignoring our own hash update');
                    return;
                }
            }
        } catch (e) {
            // Not JSON, use as-is
        }
        
        // Ignore empty or error hashes to prevent infinite loops
        if (!hashData || hashData === 'empty' || hashData === 'error' || hashData === 'reloading') {
            return;
        }
        
        // Don't process hash changes if we're already reloading
        if (isReloading) {
            console.log('[CrossTabSync] Already reloading - ignoring hash change');
            return;
        }
        
        // Additional check: ignore undefined role changes which indicate unstable state
        if (hashData.includes('undefined')) {
            return;
        }
        
        // Check if this is actually a different hash
        if (hashData !== lastKnownHistoryHash) {
            console.log('[CrossTabSync] History changed in tab:', sourceTabId || 'unknown');
            
            // Additional check to prevent rapid successive reloads
            const now = Date.now();
            if (now - lastReloadTime < 5000) { // Prevent reloads within 5 seconds
                console.log('[CrossTabSync] Skipping reload - too soon since last reload');
                return;
            }
            
            lastKnownHistoryHash = hashData;
            lastReloadTime = now;
            
            // Set reloading flag to prevent concurrent reloads
            isReloading = true;
            
            // Reload conversation history
            if (window.aiHackare && window.aiHackare.chatManager) {
                setTimeout(() => {
                    console.log('[CrossTabSync] Reloading conversation history');
                    window.aiHackare.chatManager.reloadConversationHistory();
                    
                    // Clear reloading flag after a delay
                    setTimeout(() => {
                        isReloading = false;
                        // Update our hash after reload completes
                        lastKnownHistoryHash = getHistoryHash();
                    }, 2000);
                }, 500);
            } else {
                isReloading = false;
            }
        }
    }
    
    /**
     * Start periodic sync checking
     */
    function startSyncCheck() {
        if (syncCheckInterval) {
            clearInterval(syncCheckInterval);
        }
        
        // Disable periodic checking entirely - only respond to explicit storage events
        // This prevents the infinite loops caused by self-triggering updates
        console.log('[CrossTabSync] Cross-tab sync will only respond to storage events from other tabs');
        
        // syncCheckInterval = setInterval(() => {
        //     checkForUpdates();
        // }, SYNC_CHECK_INTERVAL);
        
        // console.log('[CrossTabSync] Started periodic sync check (every', SYNC_CHECK_INTERVAL, 'ms)');
    }
    
    /**
     * Stop periodic sync checking
     */
    function stopSyncCheck() {
        if (syncCheckInterval) {
            clearInterval(syncCheckInterval);
            syncCheckInterval = null;
            console.log('[CrossTabSync] Stopped periodic sync check');
        }
    }
    
    /**
     * Check for conversation updates
     */
    function checkForUpdates() {
        try {
            // Skip updates if we're processing shared links or reloading to prevent interference
            if (window._waitingForSharedLinkPassword || window._processingSharedLink || isReloading) {
                console.log('[CrossTabSync] Skipping update check - processing in progress');
                return;
            }
            
            // Get current history hash
            const currentHistoryHash = getHistoryHash();
            
            // Track consecutive empty checks to reduce logging noise
            if (currentHistoryHash === 'empty') {
                consecutiveEmptyChecks++;
                if (consecutiveEmptyChecks > 3) {
                    // After 3 consecutive empty checks, reduce logging frequency
                    return;
                }
            } else {
                consecutiveEmptyChecks = 0;
            }
            
            // Compare with last known hash - but don't update if we just set it
            if (currentHistoryHash !== lastKnownHistoryHash) {
                // Only trigger cross-tab updates if there's actually another tab listening
                // Skip localStorage updates to prevent self-triggering events in single tab scenarios
                if (currentHistoryHash !== 'empty' && currentHistoryHash !== 'error' && 
                    lastKnownHistoryHash !== 'empty' && lastKnownHistoryHash !== 'error') {
                    console.log('[CrossTabSync] History changed locally - hash:', currentHistoryHash);
                }
                lastKnownHistoryHash = currentHistoryHash;
                // Don't call updateHistoryHash() here to prevent localStorage events in single tab
                // updateHistoryHash();
            }
            
        } catch (error) {
            console.error('[CrossTabSync] Error checking for updates:', error);
        }
    }
    
    /**
     * Process the sync queue
     */
    function processSyncQueue() {
        while (syncQueue.length > 0) {
            const syncItem = syncQueue.shift();
            
            try {
                switch (syncItem.type) {
                    case 'history_update':
                        handleHistoryUpdate(syncItem);
                        break;
                    case 'message_added':
                        handleMessageAdded(syncItem);
                        break;
                    default:
                        console.log('[CrossTabSync] Unknown sync type:', syncItem.type);
                }
            } catch (error) {
                console.error('[CrossTabSync] Error processing sync item:', error, syncItem);
            }
        }
    }
    
    /**
     * Handle history update sync
     * @param {Object} syncItem - Sync item data
     */
    function handleHistoryUpdate(syncItem) {
        console.log('[CrossTabSync] Handling history update sync');
        
        if (window.aiHackare && window.aiHackare.chatManager) {
            window.aiHackare.chatManager.reloadConversationHistory();
        }
    }
    
    /**
     * Handle message added sync
     * @param {Object} syncItem - Sync item data
     */
    function handleMessageAdded(syncItem) {
        console.log('[CrossTabSync] Handling message added sync');
        
        if (window.aiHackare && window.aiHackare.chatManager) {
            window.aiHackare.chatManager.reloadConversationHistory();
        }
    }
    
    /**
     * Trigger sync for other tabs
     * @param {string} type - Type of sync event
     * @param {Object} data - Additional data for the sync
     */
    function triggerSync(type, data = {}) {
        if (!isInitialized) {
            return;
        }
        
        try {
            const currentNamespace = NamespaceService ? NamespaceService.getNamespaceId() : null;
            
            const triggerData = {
                type,
                timestamp: Date.now(),
                namespaceId: currentNamespace,
                tabId: TAB_ID,  // Include our tab ID
                ...data
            };
            
            console.log('[CrossTabSync] Triggering sync for other tabs:', type);
            
            // Use localStorage for cross-tab communication
            // Storage events only fire in OTHER tabs, not this one
            localStorage.setItem(SYNC_TRIGGER_KEY, JSON.stringify(triggerData));
            
            // Remove the trigger after a brief moment to allow other tabs to process it
            setTimeout(() => {
                localStorage.removeItem(SYNC_TRIGGER_KEY);
            }, 100);
            
        } catch (error) {
            console.error('[CrossTabSync] Error triggering sync:', error);
        }
    }
    
    /**
     * Get hash of current conversation history
     * @returns {string} Hash of the conversation history
     */
    function getHistoryHash() {
        try {
            // Don't generate hash during reload to prevent inconsistencies
            if (isReloading) {
                return lastKnownHistoryHash || 'reloading';
            }
            
            const history = StorageService ? StorageService.loadChatHistory() : null;
            if (!history || !Array.isArray(history)) {
                return 'empty';
            }
            
            // Create a stable hash based on message count and content (not timestamps)
            const messageCount = history.length;
            if (messageCount === 0) {
                return 'empty';
            }
            
            // Use content hash instead of timestamp to avoid constant changes
            const lastMessage = history[history.length - 1];
            const lastContent = lastMessage && lastMessage.content ? lastMessage.content : '';
            const lastRole = lastMessage && lastMessage.role ? lastMessage.role : 'unknown';
            
            // Create a more stable hash that only changes when actual content changes
            // Use a simple checksum of content instead of content itself to avoid issues
            let contentChecksum = 0;
            for (let i = 0; i < lastContent.length; i++) {
                contentChecksum += lastContent.charCodeAt(i);
            }
            
            return `${messageCount}_${lastContent.length}_${lastRole}_${contentChecksum}`;
        } catch (error) {
            console.error('[CrossTabSync] Error getting history hash:', error);
            return 'error';
        }
    }
    
    /**
     * Update the stored history hash - USING PROPER HACKARE_ PREFIXED KEY
     * Note: Cross-tab sync requires direct localStorage access for storage events to work
     */
    function updateHistoryHash() {
        try {
            const currentHash = getHistoryHash();
            // Include tab ID with the hash to identify source
            const hashData = JSON.stringify({
                hash: currentHash,
                tabId: TAB_ID,
                timestamp: Date.now()
            });
            // Use direct localStorage with proper hackare_ prefix for cross-tab sync
            localStorage.setItem(HISTORY_HASH_KEY, hashData);
            lastKnownHistoryHash = currentHash;
        } catch (error) {
            console.error('[CrossTabSync] Error updating history hash:', error);
        }
    }
    
    /**
     * Notify that conversation history was updated
     */
    function notifyHistoryUpdate() {
        // Only update if we have meaningful changes and aren't reloading
        if (!isReloading && isInitialized) {
            const currentHash = getHistoryHash();
            // Only notify if the hash actually changed
            if (currentHash !== lastKnownHistoryHash && currentHash !== 'empty' && currentHash !== 'error') {
                console.log('[CrossTabSync] Notifying history update:', currentHash);
                updateHistoryHash();
                triggerSync('history_update');
            }
        }
    }
    
    /**
     * Notify that a message was added
     */
    function notifyMessageAdded() {
        // Only update if we have meaningful changes and aren't reloading
        if (!isReloading && isInitialized) {
            const currentHash = getHistoryHash();
            // Only notify if the hash actually changed
            if (currentHash !== lastKnownHistoryHash && currentHash !== 'empty' && currentHash !== 'error') {
                console.log('[CrossTabSync] Notifying message added:', currentHash);
                updateHistoryHash();
                triggerSync('message_added');
            }
        }
    }
    
    /**
     * Clean up sync service
     */
    function destroy() {
        if (!isInitialized) {
            return;
        }
        
        console.log('[CrossTabSync] Destroying cross-tab sync service');
        
        window.removeEventListener('storage', handleStorageEvent);
        stopSyncCheck();
        
        // Clear any remaining data
        try {
            localStorage.removeItem(SYNC_TRIGGER_KEY);
        } catch (error) {
            // Ignore errors when cleaning up
        }
        
        isInitialized = false;
    }
    
    // Public API
    return {
        init,
        destroy,
        triggerSync,
        notifyHistoryUpdate,
        notifyMessageAdded,
        isInitialized: () => isInitialized
    };
})();

// Auto-initialize when DOM is ready and other services are loaded
document.addEventListener('DOMContentLoaded', function() {
    // Wait for other services to be ready
    setTimeout(() => {
        if (window.StorageTypeService && window.NamespaceService && window.StorageService) {
            window.CrossTabSyncService.init();
        } else {
            console.log('[CrossTabSync] Required services not ready, will try again...');
            // Try again after a longer delay
            setTimeout(() => {
                window.CrossTabSyncService.init();
            }, 2000);
        }
    }, 1000);
});